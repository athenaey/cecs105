public interface EmployeeInfo {
	/**
	 * Interface that creates two constant variables facultymonthlysalary
	 * and staffmonthlyhoursworked
	 */
	double FACULTY_MONTHLY_SALARY = 6000.00;
	double STAFF_MONTHLY_HOURS_WORKED = 160;
}
