import java.util.*;
import java.lang.Comparable;

public abstract class Employee implements Comparable<Employee>{ // fill in the blanks!
	/**
	 * creates private the private variables lastname,firstname
	 * id num, and sex, and birthday
	 * 
	 */
	
	private String lastName;
	private String firstName;
	private String IDnum;
	private String sex;
	private Calendar birthday = new GregorianCalendar();
	
	/**
	 * default constructor for employee
	 */
	public Employee()
	{
		lastName = "";
		firstName = "";
		IDnum = "";
		sex = "";
		birthday = new GregorianCalendar() ;
			
	}
	/**
	 * creates default argument constructor for Employee
	 * @param l
	 * @param f
	 * @param ID
	 * @param s
	 * @param d
	 * @param m
	 * @param y
	 */
	public Employee(String l, String f, String ID, String s, 
			int d, int m, int y)
	{
		lastName = l;
		firstName = f;
		IDnum = ID;
		sex = s;
		birthday.set(y,m,d);
	}
	
	/**
	 * displays employee info by descending order by last name
	 */
	public int compareTo(Employee e)
	{
		return e.lastName.compareTo(this.lastName);
	}
	
	/**
	 * function that prints out the string for Employee
	 */
	public String toString()
	{
		return "Employee name: " + 
				firstName + " " + lastName + " " +"\n"+ "ID: "  + IDnum +"\n"+ "Sex: " + sex  + 
	 "\nBirthday: " + birthday.get(Calendar.MONTH)+"/"+ birthday.get(Calendar.DAY_OF_MONTH)+"/" + birthday.get(Calendar.YEAR);
	}
	/**
	 * sets lastname to l
	 * @param l
	 */
	public void setlastName(String l)
	{
		lastName = l;
	}
	/**
	 * sets firstname to f
	 * @param f
	 */
	public void setfirstName(String f)
	{
		firstName = f;
	}
	/**
	 * sets idnum to id
	 * @param ID
	 */
	public void setIDnum(String ID)
	{
		IDnum = ID;
	}
	/**
	 * sets sex to s
	 * @param s
	 */
	public void setSex(String s)
	{
		sex = s;
	}
	/**
	 * sets birthday to year month and day
	 * @param d
	 * @param m
	 * @param y
	 */
	public void setBirthday(int d, int m, int y)
	{
		birthday.set(y, m,d);
	}
	/**
	 * returns the lastname
	 * @return
	 */
	public String getlastName()
	{
		return lastName;
	}
	/**
	 * returns the first name
	 * @return
	 */
	public String getfirstName()
	{
		return firstName;
	}
	/**
	 * returns the idnum
	 * @return
	 */
	public String getIDnum()
	{
		return IDnum;
	}
	/**
	 * returns the sex
	 * @return
	 */
	public String getSex()
	{
		return sex;
	}
	/**
	 * returns the birthday
	 * @return
	 */
	public String getBirthday()
	{
		return birthday.get(Calendar.MONTH)+"/"+ birthday.get(Calendar.DAY_OF_MONTH)+"/" + birthday.get(Calendar.YEAR);
	}
	
	/**
	 * abstract method for monthly earning
	 * @return
	 */
	abstract double monthlyEarning(double STAFF_MONTHLY_HOURS_WORKED);
}