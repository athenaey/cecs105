
public class Faculty extends Employee implements EmployeeInfo { // fill in the blanks
	/**
	 * creates an enum that has string as, ao, and fu
	 * 
	 * @author BrandonYu
	 *
	 */
	public enum Level {
		AS, AO, FU
	}

	/**
	 * creates private variables salary, level, and education
	 */
	private double salary = EmployeeInfo.FACULTY_MONTHLY_SALARY;
	Level level;
	private Education education;

	/**
	 * creates default constructor faculty
	 */
	Faculty() {
		salary = EmployeeInfo.FACULTY_MONTHLY_SALARY;
		education = new Education();
		level = Level.FU;
	}

	/**
	 * creates default argument constructor for faculty
	 * 
	 * @param l
	 * @param f
	 * @param ID
	 * @param s
	 * @param d
	 * @param m
	 * @param y
	 * @param deg
	 * @param maj
	 * @param res
	 * @param level
	 */
	Faculty(String l, String f, String ID, String s, int d, int m, int y, String deg, String maj, int res,
			String level) {
		super(l, f, ID, s, d, m, y);
		education = new Education(deg, maj, res);
		setLevel(level);
	}

	/**
	 * function that sets level either to as, ao, or fu
	 * 
	 * @param l
	 */
	private void setLevel(String l) {
		if (l.equals("AS"))
			level = Level.AS;
		else if (l.equals("AO"))
			level = Level.AO;
		else
			level = Level.FU;
	}

	/**
	 * function that returns the level either as assistant, associate, or full
	 * 
	 * @return
	 */
	public String getLevel() {
		if (level == Level.AS)
			return "Assistant";
		else if (level == Level.AO)
			return "Associate";
		else
			return "Full";
	}

	/**
	 * sets education to e
	 * 
	 * @param e
	 */
	public void setEducation(Education e) {
		education = e;
	}

	/**
	 * returns the education
	 * 
	 * @return
	 */
	
	public Education getEducation() {
		return education;
	}

	/**
	 * returns the monthly earning of the faculty
	 */
	public double monthlyEarning(double FACULTY_MONTHLY_SALARY) {
		if (level == Level.AS)
			return salary;
		else if (level == Level.AO)
			return salary * 1.5;
		else
			return salary * 2;
	}

	/**
	 * returns the string output for faulty information
	 */
	public String toString() {
		return "Employee name: " + getfirstName() + " " + getlastName() + "\n" +
			   "ID Employee number: " + getIDnum() + "\n" + "Sex: " + getSex() + "\n" + 
			   "Birthday: " + getBirthday() + "\n" + "Level: " + level + "\n" + 
			   "Degree: " + education.getDegree() + "\n" + "Major: " + education.getMajor() + 
			   "\n" + "Research: " + education.getResearch() + "\n" +
			   "Monthly Salary: " + monthlyEarning(FACULTY_MONTHLY_SALARY);
	}	
}