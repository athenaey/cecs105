
public class Education {
	/**
	 * creating variables Degree, Major, and Research
	 */
	private String Degree;
	private String Major;
	private int Research;
	
	/**
	 * default constructor for Education
	 */
	public Education()
	{
		Degree = "";
		Major = "";
		Research = 0;
		
	}
	/**
	 * Default argument constructor for Education
	 * @param deg
	 * @param maj
	 * @param res
	 */
	public Education(String deg, String maj, int res)
	{
		Degree = deg;
		Major = maj;
		Research = res;
	}
	/**
	 * returns the degree
	 * @return
	 */
	public String getDegree()
	{
		return Degree;
	}
	/**
	 * returns the Major
	 * @return
	 */
	public String getMajor()
	{
		return Major;
	}
	/**
	 * returns Research
	 * @return
	 */
	public int getResearch()
	{
		return Research;
	}
	/**
	 * Sets degree to deg
	 * @param deg
	 */
	public void setDegree(String deg)
	{
		Degree = deg;
	}
	/**
	 * sets major to maj
	 * @param maj
	 */
	public void setMajor(String maj)
	{
		Major = maj;
	}
	/**
	 * sets research to res
	 */
	public void setResearch(int res)
	{
		Research = res;
	}
	/**
	 * clone function that clones an object
	 */
	// create a clone function?
}
