import java.util.ArrayList;
import java.util.Collections;

public class lab8demo {

	public static void main(String[] args) {
		ArrayList<Employee> e = new ArrayList<Employee>();
		e.add(new Faculty("Johnson", "Anna", "243", "F", 27, 4, 62, "Ph.D", "Engineering", 3, "FU"));
		e.add(new Staff("Allen", "Paita", "123", "F", 23, 2, 1959, 50.0));
		e.add(new Partime("Guzman", "Augusto", "455", "M", 10, 8, 1977, 35.0, 30.0));
		e.add(new Partime("Depirro", "Martin", "678", "M", 15, 9, 1987, 30.0, 15.0));
		e.add(new Staff("Zapata", "Steven", "456", "F", 7, 1, 1965, 35.0));
		e.add(new Faculty("Bouris", "William", "791", "M", 14, 3, 1975, "Ph.D", "English", 1, "AO"));
		e.add(new Staff("Rios", "Enrique", "123", "M", 6, 2, 1970, 40.0));
		e.add(new Faculty("Andrade", "Chrisopher", "623", "M", 22, 5, 1980, "MS", "Physical Education", 0, "AS"));
		e.add(new Partime("Aldaco", "Marque", "945", "M", 24, 11, 1988, 20.0, 35.0));
		
		Collections.sort(e);
		System.out.println("Sorting employees by last name in descending order:\n");
		for(Employee employee: e)
		{
			System.out.println(employee + "\n");
		}
		System.out.println("____________________________________________");
		System.out.println("Soring employees by ID in ascending order:\n");
		IDCompare idCompare = new IDCompare();
		Collections.sort(e, idCompare);
		for(Employee employee: e)
		{
			System.out.println(employee + "\n");
		}
	}
}