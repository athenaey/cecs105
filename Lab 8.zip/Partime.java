public class Partime extends Staff { // fill in the blanks!

	/**
	 * creates a private variable called hours
	 */
	private double hours;
	/**
	 * default constructor for partime
	 */
	Partime()
	{
		super();
		hours = 0.0;
	}
	/**
	 * default argument constructor for partime
	 * @param l
	 * @param f
	 * @param ID
	 * @param s
	 * @param d
	 * @param m
	 * @param y
	 * @param r
	 * @param hr
	 */
	Partime(String l, String f, String ID, String s, int d, int m, int y, double r, double hr)
	{
		super(l, f, ID, s, d, m, y, r);
		hours = hr;
	}
	/**
	 * sets hours to h
	 * @param h
	 */
	public void setHours(double h)
	{
		hours = h;
	}
	/**
	 * returns the number of hours
	 * @return
	 */
	public double getHours()
	{
		return hours;
	}
	/**
	 * returns the monthly earning for partime
	 */
	public double monthlyEarning()
	{
		return getHourlyRate() * (hours * 4);
	}
	
	/**
	 * prints out the string for partime information
	 */
	public String toString()
	{
		return "Employee name: " + getfirstName() + " " + getlastName() + "\n" +
			   "ID Employee number: " + getIDnum() + "\n" +
			   "Sex: " + getSex() + "\n" + "Birthday: " + getBirthday() + "\n" +
			   "Hours worked per week: "+ hours + "\n" +
			   "Hours worked per month: " + (hours * 4) + "\n" +
			   "Monthly Salary: " + monthlyEarning();
	}
}