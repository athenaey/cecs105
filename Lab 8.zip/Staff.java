//import java.util.GregorianCalendar;

public class Staff extends Employee implements EmployeeInfo { // fill in the blanks!

	/**
	 * creates a private variable called hourlyrate
	 */
	private double hourlyRate;
	
/**
 * creates default constructor for staff
 */
	Staff()
	{
		super();
		hourlyRate = 0;
	}
	
/**
 * creates default argument constructor for staff
 * @param l
 * @param f
 * @param ID
 * @param s
 * @param d
 * @param m
 * @param y
 * @param r
 */
	Staff(String l, String f, String ID, String s, int d, int m, int y, double r)
		{
		super(l, f, ID, s, d, m, y);
		hourlyRate = r;
		}
	/**
	 * function that returns the hourlyrate
	 * @return
	 */
	public double getHourlyRate()
		{
		return hourlyRate;
		}
	/**
	 * sets hourly rate to h
	 * @param h
	 */
	public void setHourlyRate(double h)
		{
		hourlyRate = h;
		}
	/**
	 * function that calculates the monthly earning for staff
	 * @param STAFF_MONTHLY_HOURS_WORKED 
	 */
	@Override
	double monthlyEarning(double STAFF_MONTHLY_HOURS_WORKED) {
		return STAFF_MONTHLY_HOURS_WORKED * hourlyRate;
	}
	
	/**
	 * prints out the string for staff information
	 */
	public String toString()
		{
		return "Employee name: " + getfirstName() + " " + getlastName() + "\n" +
			   "ID Employee number: " + getIDnum() + "\n" +
			   "Sex: " + getSex() + "\n" + "Birthday: " + getBirthday() + "\n" +
			   "Full Time" + "\n" + "Hourly rate: " + hourlyRate + "\n" + 
			   "Monthly Salary: " + monthlyEarning(STAFF_MONTHLY_HOURS_WORKED); 
		}
}