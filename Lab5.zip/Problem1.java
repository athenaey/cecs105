package Lab5;
//import java.util.ArrayList;

public class Problem1 {

	public static void main(String[] args) {
		Student stu1 = new Student("Athena Yiv", 1, "027060967");
		//ArrayList<Class> classes = new ArrayList<>(4);
		Class c1 = new Class("CECS 2", 4.3); // 100.0
		Class c2 = new Class("CECS 1", 3.3); // 86.0
		Class c3 = new Class("CWL 215", 4.0); // 94.0
		Class c4 = new Class("CECS 3", 2.0); // 75.0
		Class[] classes = {c1, c2, c3, c4};
//		classes.add(c1);
//		classes.add(c2);
//		classes.add(c3);
//		classes.add(c4);
		StudentReportCard src1 = new StudentReportCard(stu1, classes);
		System.out.println(src1);
	}

}
